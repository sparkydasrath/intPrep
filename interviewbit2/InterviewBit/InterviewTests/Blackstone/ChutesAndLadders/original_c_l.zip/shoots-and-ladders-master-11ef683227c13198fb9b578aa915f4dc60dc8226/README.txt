In this program, you can play the ancient children's game shoots and ladders.

The game works as follows:

All players start at the beginning of the game board. They take turns spinning a number between 1 and 6. If they land on a space that is the bottom of a ladder or the top of a shoot, they follow it to the space indicated. The winner is the first player to reach the final space on the board (100!).

Hope I didn't have any bugs, I got it to compile in Visual Studio code on my last day. It'll work in regular Visual Studio too if you have .Net Core support (New hotness!) set up.

Peace out, I'm going back to school.
Joe the intern